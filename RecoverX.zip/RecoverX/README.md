# RecoverX – Deleted Message Viewer (Ultimate Edition)

Version 1.0 Ultimate · Java · XML layouts · SQLite · NotificationListenerService · Material Design 3

RecoverX saves the text of WhatsApp and WhatsApp Business notifications on your phone, so you can still read what a notification showed after the sender uses **Delete for Everyone**.

## What RecoverX does and does not do

- It uses Android's official **notification access**. It never opens WhatsApp's database, never breaks encryption, never logs into accounts, and has **no internet permission**.
- It saves only what Android shows in a notification. Messages that never appear in a notification cannot be saved. This includes chats that are already open, muted chats, chats with previews hidden, and messages that arrive while RecoverX is stopped.
- **Deleted detection is honest.** Android never tells apps that a message was deleted. RecoverX flags a message as **Possibly deleted** only when WhatsApp later shows "This message was deleted" in the same chat, from the same sender. You can also mark or unmark any message yourself.
- **Media:** WhatsApp notifications usually show only a label such as "📷 Photo". RecoverX lists these under Media but keeps a picture only if the notification itself contained one. It never claims to recover files.
- It reads only WhatsApp (`com.whatsapp`) and WhatsApp Business (`com.whatsapp.w4b`), each switchable in Settings. Banks, OTP senders and every other app are ignored.

## Project structure

```
RecoverX/
├── settings.gradle, build.gradle, gradle.properties, gradlew, gradle/wrapper/
└── app/
    ├── build.gradle
    └── src/main/
        ├── AndroidManifest.xml
        ├── java/com/recoverx/app/
        │   ├── RecoverXApp.java                    Forces the black theme
        │   ├── data/
        │   │   ├── DatabaseHelper.java             SQLite (captured_notifications), parameterized queries, migrations, change listeners
        │   │   ├── CapturedMessage.java            Record model
        │   │   ├── MessageType.java                Type detection (text, image, video, audio, document, sticker, other, hidden)
        │   │   ├── Hashing.java                    SHA-256 duplicate key
        │   │   ├── Prefs.java                      Enabled apps and options
        │   │   └── BackupManager.java              JSON export, import and local backups
        │   ├── service/NotificationCaptureService.java   The NotificationListenerService
        │   ├── util/AppUtils.java                  Access checks, Xiaomi pages, background work, English formatting
        │   └── ui/
        │       ├── SplashActivity, OnboardingActivity, SetupActivity, MainActivity
        │       ├── HomeFragment, MessagesFragment, DeletedFragment, SettingsFragment, BaseListFragment
        │       ├── SearchActivity, MediaActivity, BackupActivity, AboutActivity
        │       ├── MessageAdapter.java             List rows
        │       └── UiHelper.java                   Toolbar, type chips, message detail dialog
        └── res/  layout (18), drawable, menu, values (strings, colors, themes), mipmap
```

The listener class is named `NotificationCaptureService.java`, not `NotificationListenerService.java`, because a class with the same name as Android's `NotificationListenerService` would clash with the class it extends.

### Database: `captured_notifications`

`id`, `package_name`, `conversation`, `sender_name`, `message_text`, `timestamp`, `message_type`, `manually_marked_deleted`, `possibly_deleted`, `media_path`, `dedupe_key` (UNIQUE), `created_at`. It has indexes on time, sender and chat. Inserts use `INSERT OR IGNORE` on the duplicate key, so WhatsApp re-posting the same grouped notification never creates duplicates. Version-by-version migrations go in `onUpgrade`.

## Screens

Splash · Onboarding (3 pages) · Permission setup · Dashboard · All Messages · Deleted Messages · Search (sender or text, type, date range, sort) · Media (Images, Videos, Audio, Documents) · Backup & Restore · Settings · About. A message detail dialog offers Copy, Mark as Deleted or Unmark, and Delete.

## Build and install

1. Open **Android Studio**, choose **Open**, and select the `RecoverX` folder.
2. Wait for **Gradle sync** to finish. It needs internet the first time.
3. Choose **Build → Make Project**.
4. Choose **Build → Build APK(s)**. The file is `app/build/outputs/apk/debug/app-debug.apk`.
5. Copy the APK to the Redmi 14C 5G, tap it, allow **Install unknown apps** and tap **Install**.

**From a phone with GitHub:** create a new repository with a README, upload **RecoverX.zip**, then add `.github/workflows/main.yml` with the same build text as the earlier apps. Download the APK from **Actions → Artifacts**.

**Signed release APK:** choose **Build → Generate Signed App Bundle / APK → APK**, then **Create new** keystore (keep the file and passwords private and backed up). Choose **release** and finish. The APK is in `app/release/`.

## Enable notification access on the Redmi 14C 5G

1. Open RecoverX. The setup screen appears after onboarding.
2. Tap **Open Notification Access**, find **RecoverX**, turn it on and confirm.
3. **If Android shows "Restricted setting"** (Android 13 and newer block this for apps installed from an APK): go back and tap **Open App Info**. Tap **⋮** (top right), then **Allow restricted settings**, and confirm. Then repeat step 2.
4. Xiaomi background settings: **Settings → Apps → Manage apps → RecoverX**. Turn on **Autostart** and set **Battery saver** to **No restrictions**. Also lock RecoverX in the Recents screen. The app's Settings screen has shortcuts for these.

RecoverX cannot promise uninterrupted background operation. Android and HyperOS can still stop background apps.

## Testing checklist

| Scenario | Expected result |
|---|---|
| Normal WhatsApp text from another phone | It appears in Home and Messages with sender, time and the Text type. |
| Sender deletes it for everyone | If WhatsApp shows "This message was deleted", the saved message is flagged **Possibly deleted** and appears under Deleted. Otherwise, mark it yourself from the detail dialog. |
| Notification access turned off | The Home warning card and Settings status show it is off. Nothing new is saved. |
| Empty notification | It is ignored. |
| Several messages from one sender | Each is saved once, with no duplicates when WhatsApp re-posts the group. |
| Phone restart | Android reconnects the listener once access is on (Autostart helps on Xiaomi). Saved records remain. |
| Database persistence | Records stay after closing the app. |
| Search | Matches sender, chat or text. Type and date filters and sort order work. |
| Export and import | Export creates a JSON file. Import adds records and skips duplicates. |
| Missing notification preview | Saved as **Preview hidden** ("New message"). |
| Media without an accessible file | Listed under Media with "WhatsApp did not include this file in the notification". |

## Troubleshooting

- **Nothing is saved:** check that notification access is on, that WhatsApp notifications are allowed and show message previews, and that the chat is not open or muted.
- **"Restricted setting":** see step 3 above.
- **It stops after a while:** turn on Autostart, set Battery saver to No restrictions and lock the app in Recents.
- **Wrong "Possibly deleted" flags:** open the message and tap **Unmark**, or turn off auto-flagging in Settings.

## Testing status (honest)

This workspace has no Android SDK, so the project has **not been compiled against Android or run on a phone**. I checked it as follows:
- `javac` parsed every Java file with no syntax errors. The only errors were the missing Android classes.
- Every XML file is valid.
- Every resource and view ID referenced in the code exists.
- All of the app's own imports resolve, and package names match their folders.
- All UI text is English.

Please build it and send any error, and it will be fixed.

## Privacy

Use RecoverX only for notifications on your own phone. It has no internet permission, no accounts, no ads and no analytics. Records and backups stay on the device or in the location you choose.
