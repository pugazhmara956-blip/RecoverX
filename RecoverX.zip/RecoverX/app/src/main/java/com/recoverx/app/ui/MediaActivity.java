package com.recoverx.app.ui;

import android.content.Context;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.tabs.TabLayout;
import com.recoverx.app.R;
import com.recoverx.app.data.CapturedMessage;
import com.recoverx.app.data.DatabaseHelper;
import com.recoverx.app.data.MessageType;
import com.recoverx.app.util.AppUtils;

import java.util.List;

/** Media notifications grouped into Images, Videos, Audio and Documents. */
public class MediaActivity extends AppCompatActivity implements DatabaseHelper.ChangeListener {

    private static final String[] TYPES = {MessageType.IMAGE, MessageType.VIDEO, MessageType.AUDIO, MessageType.DOCUMENT};
    private static final int[] LABELS = {R.string.tab_images, R.string.tab_videos, R.string.tab_audio, R.string.tab_documents};
    private static final String KEY_TAB = "tab";

    private int selected = 0;
    private MessageAdapter adapter;
    private TextView emptyText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_media);
        UiHelper.setupToolbar(this, R.string.media_title);
        if (savedInstanceState != null) selected = savedInstanceState.getInt(KEY_TAB, 0);

        emptyText = findViewById(R.id.empty_text);
        RecyclerView list = findViewById(R.id.list);
        list.setLayoutManager(new LinearLayoutManager(this));
        adapter = new MessageAdapter(m -> UiHelper.showMessageDetail(this, m));
        list.setAdapter(adapter);

        TabLayout tabs = findViewById(R.id.tabs);
        for (int label : LABELS) tabs.addTab(tabs.newTab().setText(label));
        TabLayout.Tab initial = tabs.getTabAt(selected);
        if (initial != null) initial.select();
        tabs.addOnTabSelectedListener(new TabLayout.OnTabSelectedListener() {
            @Override
            public void onTabSelected(TabLayout.Tab tab) {
                selected = tab.getPosition();
                reload();
            }

            @Override
            public void onTabUnselected(TabLayout.Tab tab) {
            }

            @Override
            public void onTabReselected(TabLayout.Tab tab) {
            }
        });
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        outState.putInt(KEY_TAB, selected);
    }

    @Override
    protected void onStart() {
        super.onStart();
        DatabaseHelper.addListener(this);
        reload();
    }

    @Override
    protected void onStop() {
        DatabaseHelper.removeListener(this);
        super.onStop();
    }

    @Override
    public void onDataChanged() {
        reload();
    }

    private void reload() {
        final Context app = getApplicationContext();
        final DatabaseHelper.Filter f = new DatabaseHelper.Filter();
        f.type = TYPES[selected];
        AppUtils.background(() -> DatabaseHelper.get(app).query(f), (List<CapturedMessage> list) -> {
            if (isFinishing()) return;
            adapter.submit(list);
            emptyText.setVisibility(list.isEmpty() ? View.VISIBLE : View.GONE);
            emptyText.setText(R.string.no_media);
        }, null);
    }
}
