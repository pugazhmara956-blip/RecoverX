package com.recoverx.app.data;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;

import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;

/** SQLite storage for captured notifications. All queries use bound parameters. */
public class DatabaseHelper extends SQLiteOpenHelper {

    private static final String TAG = "DatabaseHelper";
    public static final String DB_NAME = "recoverx.db";
    private static final int DB_VERSION = 1;

    public static final String TABLE = "captured_notifications";
    public static final String COL_ID = "id";
    public static final String COL_PACKAGE = "package_name";
    public static final String COL_CONVERSATION = "conversation";
    public static final String COL_SENDER = "sender_name";
    public static final String COL_TEXT = "message_text";
    public static final String COL_TIMESTAMP = "timestamp";
    public static final String COL_TYPE = "message_type";
    public static final String COL_MARKED = "manually_marked_deleted";
    public static final String COL_POSSIBLY = "possibly_deleted";
    public static final String COL_MEDIA = "media_path";
    public static final String COL_DEDUPE = "dedupe_key";
    public static final String COL_CREATED = "created_at";

    /** Notified on the main thread whenever records change, so open screens can refresh. */
    public interface ChangeListener {
        void onDataChanged();
    }

    private static volatile DatabaseHelper instance;
    private static final List<ChangeListener> listeners = new CopyOnWriteArrayList<>();
    private static final Handler mainHandler = new Handler(Looper.getMainLooper());
    private final Context appContext;

    public static DatabaseHelper get(Context context) {
        if (instance == null) {
            synchronized (DatabaseHelper.class) {
                if (instance == null) instance = new DatabaseHelper(context.getApplicationContext());
            }
        }
        return instance;
    }

    private DatabaseHelper(Context context) {
        super(context, DB_NAME, null, DB_VERSION);
        appContext = context;
    }

    public static void addListener(ChangeListener l) {
        listeners.add(l);
    }

    public static void removeListener(ChangeListener l) {
        listeners.remove(l);
    }

    private static void notifyChanged() {
        mainHandler.post(() -> {
            for (ChangeListener l : listeners) l.onDataChanged();
        });
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE " + TABLE + " ("
                + COL_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, "
                + COL_PACKAGE + " TEXT NOT NULL, "
                + COL_CONVERSATION + " TEXT, "
                + COL_SENDER + " TEXT, "
                + COL_TEXT + " TEXT, "
                + COL_TIMESTAMP + " INTEGER NOT NULL, "
                + COL_TYPE + " TEXT NOT NULL, "
                + COL_MARKED + " INTEGER NOT NULL DEFAULT 0, "
                + COL_POSSIBLY + " INTEGER NOT NULL DEFAULT 0, "
                + COL_MEDIA + " TEXT, "
                + COL_DEDUPE + " TEXT NOT NULL UNIQUE, "
                + COL_CREATED + " INTEGER NOT NULL)");
        db.execSQL("CREATE INDEX idx_timestamp ON " + TABLE + " (" + COL_TIMESTAMP + ")");
        db.execSQL("CREATE INDEX idx_sender ON " + TABLE + " (" + COL_SENDER + ")");
        db.execSQL("CREATE INDEX idx_conversation ON " + TABLE + " (" + COL_PACKAGE + ", " + COL_CONVERSATION + ")");
    }

    /**
     * Step-by-step migrations. Each future version adds a case; data is never dropped.
     * Example for version 2: case 1: db.execSQL("ALTER TABLE ... ADD COLUMN ...");
     */
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        Log.i(TAG, "Upgrading database from " + oldVersion + " to " + newVersion);
    }

    // ------------------------------------------------------------------ writes

    /** Inserts a message unless an identical one is already saved. Returns the new id, or -1. */
    public long insertIfNew(CapturedMessage m) {
        ContentValues cv = toValues(m);
        long id;
        try {
            id = getWritableDatabase().insertWithOnConflict(TABLE, null, cv, SQLiteDatabase.CONFLICT_IGNORE);
        } catch (Exception e) {
            Log.w(TAG, "Insert failed", e);
            return -1;
        }
        if (id != -1) notifyChanged();
        return id;
    }

    /**
     * Flags the latest earlier message from this sender in this chat as possibly deleted.
     * Called when WhatsApp shows "This message was deleted".
     */
    public void flagLatestAsPossiblyDeleted(String packageName, String conversation, String sender, long beforeTime) {
        try {
            SQLiteDatabase db = getWritableDatabase();
            String where = COL_PACKAGE + " = ? AND " + COL_CONVERSATION + " = ? AND " + COL_SENDER + " = ? AND "
                    + COL_TIMESTAMP + " <= ? AND " + COL_POSSIBLY + " = 0";
            String[] args = {packageName, nullToEmpty(conversation), nullToEmpty(sender), String.valueOf(beforeTime)};
            long targetId = -1;
            try (Cursor c = db.query(TABLE, new String[]{COL_ID}, where, args, null, null, COL_TIMESTAMP + " DESC", "1")) {
                if (c.moveToFirst()) targetId = c.getLong(0);
            }
            if (targetId == -1) return;
            ContentValues cv = new ContentValues();
            cv.put(COL_POSSIBLY, 1);
            db.update(TABLE, cv, COL_ID + " = ?", new String[]{String.valueOf(targetId)});
            notifyChanged();
        } catch (Exception e) {
            Log.w(TAG, "Could not flag deleted message", e);
        }
    }

    public void setManuallyDeleted(long id, boolean deleted) {
        ContentValues cv = new ContentValues();
        cv.put(COL_MARKED, deleted ? 1 : 0);
        if (!deleted) cv.put(COL_POSSIBLY, 0);
        getWritableDatabase().update(TABLE, cv, COL_ID + " = ?", new String[]{String.valueOf(id)});
        notifyChanged();
    }

    public void delete(CapturedMessage m) {
        getWritableDatabase().delete(TABLE, COL_ID + " = ?", new String[]{String.valueOf(m.id)});
        deleteMediaFile(m.mediaPath);
        notifyChanged();
    }

    public void clearAll() {
        getWritableDatabase().delete(TABLE, null, null);
        File dir = new File(appContext.getFilesDir(), "media");
        File[] files = dir.listFiles();
        if (files != null) for (File f : files) //noinspection ResultOfMethodCallIgnored
            f.delete();
        notifyChanged();
    }

    // ------------------------------------------------------------------ reads

    /** Search and filter options. Null values mean "no filter". */
    public static class Filter {
        public String query;
        public String type;
        public Long fromMillis;
        public Long toMillis;
        public boolean deletedOnly;
        public boolean mediaOnly;
        public boolean newestFirst = true;
        public int limit = 0;
    }

    public List<CapturedMessage> query(Filter f) {
        StringBuilder where = new StringBuilder("1 = 1");
        List<String> args = new ArrayList<>();
        if (f.query != null && !f.query.trim().isEmpty()) {
            String like = "%" + f.query.trim() + "%";
            where.append(" AND (").append(COL_SENDER).append(" LIKE ? OR ")
                    .append(COL_CONVERSATION).append(" LIKE ? OR ")
                    .append(COL_TEXT).append(" LIKE ?)");
            args.add(like);
            args.add(like);
            args.add(like);
        }
        if (f.type != null) {
            where.append(" AND ").append(COL_TYPE).append(" = ?");
            args.add(f.type);
        }
        if (f.fromMillis != null) {
            where.append(" AND ").append(COL_TIMESTAMP).append(" >= ?");
            args.add(String.valueOf(f.fromMillis));
        }
        if (f.toMillis != null) {
            where.append(" AND ").append(COL_TIMESTAMP).append(" < ?");
            args.add(String.valueOf(f.toMillis));
        }
        if (f.deletedOnly) {
            where.append(" AND (").append(COL_MARKED).append(" = 1 OR ").append(COL_POSSIBLY).append(" = 1)");
        }
        if (f.mediaOnly) {
            where.append(" AND ").append(COL_TYPE).append(" IN (?, ?, ?, ?)");
            args.add(MessageType.IMAGE);
            args.add(MessageType.VIDEO);
            args.add(MessageType.AUDIO);
            args.add(MessageType.DOCUMENT);
        }
        String order = COL_TIMESTAMP + (f.newestFirst ? " DESC" : " ASC") + ", " + COL_ID + (f.newestFirst ? " DESC" : " ASC");
        String limit = f.limit > 0 ? String.valueOf(f.limit) : null;
        List<CapturedMessage> list = new ArrayList<>();
        try (Cursor c = getReadableDatabase().query(TABLE, null, where.toString(), args.toArray(new String[0]), null, null, order, limit)) {
            while (c.moveToNext()) list.add(fromCursor(c));
        } catch (Exception e) {
            Log.w(TAG, "Query failed", e);
        }
        return list;
    }

    public List<CapturedMessage> all() {
        Filter f = new Filter();
        f.newestFirst = false;
        return query(f);
    }

    public static class Stats {
        public long total;
        public long text;
        public long today;
        public long deleted;
        public long storageBytes;
    }

    public Stats stats(long startOfToday) {
        Stats s = new Stats();
        SQLiteDatabase db = getReadableDatabase();
        s.total = count(db, null, null);
        s.text = count(db, COL_TYPE + " = ?", new String[]{MessageType.TEXT});
        s.today = count(db, COL_TIMESTAMP + " >= ?", new String[]{String.valueOf(startOfToday)});
        s.deleted = count(db, COL_MARKED + " = 1 OR " + COL_POSSIBLY + " = 1", null);
        s.storageBytes = sizeOf(appContext.getDatabasePath(DB_NAME)) + sizeOf(new File(appContext.getFilesDir(), "media"));
        return s;
    }

    private long count(SQLiteDatabase db, String where, String[] args) {
        try (Cursor c = db.query(TABLE, new String[]{"COUNT(*)"}, where, args, null, null, null)) {
            return c.moveToFirst() ? c.getLong(0) : 0;
        } catch (Exception e) {
            return 0;
        }
    }

    // ------------------------------------------------------------------ helpers

    private static ContentValues toValues(CapturedMessage m) {
        ContentValues cv = new ContentValues();
        cv.put(COL_PACKAGE, m.packageName);
        cv.put(COL_CONVERSATION, nullToEmpty(m.conversation));
        cv.put(COL_SENDER, nullToEmpty(m.senderName));
        cv.put(COL_TEXT, m.messageText);
        cv.put(COL_TIMESTAMP, m.timestamp);
        cv.put(COL_TYPE, m.messageType);
        cv.put(COL_MARKED, m.manuallyMarkedDeleted ? 1 : 0);
        cv.put(COL_POSSIBLY, m.possiblyDeleted ? 1 : 0);
        cv.put(COL_MEDIA, m.mediaPath);
        cv.put(COL_DEDUPE, m.dedupeKey);
        cv.put(COL_CREATED, m.createdAt);
        return cv;
    }

    private static CapturedMessage fromCursor(Cursor c) {
        CapturedMessage m = new CapturedMessage();
        m.id = c.getLong(c.getColumnIndexOrThrow(COL_ID));
        m.packageName = c.getString(c.getColumnIndexOrThrow(COL_PACKAGE));
        m.conversation = c.getString(c.getColumnIndexOrThrow(COL_CONVERSATION));
        m.senderName = c.getString(c.getColumnIndexOrThrow(COL_SENDER));
        m.messageText = c.getString(c.getColumnIndexOrThrow(COL_TEXT));
        m.timestamp = c.getLong(c.getColumnIndexOrThrow(COL_TIMESTAMP));
        m.messageType = c.getString(c.getColumnIndexOrThrow(COL_TYPE));
        m.manuallyMarkedDeleted = c.getInt(c.getColumnIndexOrThrow(COL_MARKED)) == 1;
        m.possiblyDeleted = c.getInt(c.getColumnIndexOrThrow(COL_POSSIBLY)) == 1;
        m.mediaPath = c.getString(c.getColumnIndexOrThrow(COL_MEDIA));
        m.dedupeKey = c.getString(c.getColumnIndexOrThrow(COL_DEDUPE));
        m.createdAt = c.getLong(c.getColumnIndexOrThrow(COL_CREATED));
        return m;
    }

    static String nullToEmpty(String s) {
        return s == null ? "" : s;
    }

    private static long sizeOf(File f) {
        if (f == null || !f.exists()) return 0;
        if (f.isFile()) return f.length();
        long total = 0;
        File[] children = f.listFiles();
        if (children != null) for (File child : children) total += sizeOf(child);
        return total;
    }

    private static void deleteMediaFile(String path) {
        if (path == null) return;
        File f = new File(path);
        if (f.exists()) //noinspection ResultOfMethodCallIgnored
            f.delete();
    }
}
