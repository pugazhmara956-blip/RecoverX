package com.recoverx.app.data;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;

/** Builds a stable key so the same notification message is never saved twice. */
public final class Hashing {
    private Hashing() {
    }

    public static String dedupeKey(String pkg, String conversation, String sender, String text, long timestamp) {
        String raw = pkg + "\u0001" + conversation + "\u0001" + sender + "\u0001" + text + "\u0001" + timestamp;
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            byte[] digest = md.digest(raw.getBytes(StandardCharsets.UTF_8));
            StringBuilder sb = new StringBuilder();
            for (byte b : digest) sb.append(String.format("%02x", b));
            return sb.toString();
        } catch (Exception e) {
            return String.valueOf(raw.hashCode()) + "_" + timestamp;
        }
    }
}
