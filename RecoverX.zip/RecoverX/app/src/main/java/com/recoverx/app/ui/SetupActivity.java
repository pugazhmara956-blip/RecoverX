package com.recoverx.app.ui;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import com.google.android.material.button.MaterialButton;
import com.recoverx.app.R;
import com.recoverx.app.util.AppUtils;

/** Explains notification access and opens the right Android settings page. */
public class SetupActivity extends AppCompatActivity {

    private TextView status;
    private MaterialButton continueButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_setup);
        status = findViewById(R.id.setup_status);
        continueButton = findViewById(R.id.btn_continue);
        findViewById(R.id.btn_open_access).setOnClickListener(v -> AppUtils.openNotificationAccess(this));
        findViewById(R.id.btn_app_info).setOnClickListener(v -> AppUtils.openAppInfo(this));
        continueButton.setOnClickListener(v -> {
            startActivity(new Intent(this, MainActivity.class));
            finish();
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        boolean granted = AppUtils.hasNotificationAccess(this);
        status.setText(granted ? R.string.status_access_on : R.string.status_access_off);
        status.setTextColor(ContextCompat.getColor(this, granted ? R.color.neon : R.color.warning));
        status.setBackgroundResource(granted ? R.drawable.bg_card_neon : R.drawable.bg_warning);
        continueButton.setText(granted ? R.string.continue_text : R.string.skip_for_now);
        if (granted) AppUtils.requestRebind(this);
    }
}
