package com.recoverx.app.data;

import android.content.Context;
import android.content.SharedPreferences;

/** Small user preferences stored on the phone. */
public final class Prefs {
    public static final String PKG_WHATSAPP = "com.whatsapp";
    public static final String PKG_WHATSAPP_BUSINESS = "com.whatsapp.w4b";

    private static final String FILE = "recoverx_prefs";
    private static final String KEY_ONBOARDED = "onboarded";
    private static final String KEY_AUTO_DETECT = "auto_detect_deleted";
    private static final String KEY_MEDIA = "capture_media";

    private Prefs() {
    }

    private static SharedPreferences sp(Context c) {
        return c.getApplicationContext().getSharedPreferences(FILE, Context.MODE_PRIVATE);
    }

    public static boolean isOnboarded(Context c) {
        return sp(c).getBoolean(KEY_ONBOARDED, false);
    }

    public static void setOnboarded(Context c) {
        sp(c).edit().putBoolean(KEY_ONBOARDED, true).apply();
    }

    /** Only explicitly enabled packages are ever read. Defaults: WhatsApp and WhatsApp Business. */
    public static boolean isPackageEnabled(Context c, String packageName) {
        if (!PKG_WHATSAPP.equals(packageName) && !PKG_WHATSAPP_BUSINESS.equals(packageName)) return false;
        return sp(c).getBoolean("pkg_" + packageName, true);
    }

    public static void setPackageEnabled(Context c, String packageName, boolean enabled) {
        sp(c).edit().putBoolean("pkg_" + packageName, enabled).apply();
    }

    public static boolean isAutoDetectDeleted(Context c) {
        return sp(c).getBoolean(KEY_AUTO_DETECT, true);
    }

    public static void setAutoDetectDeleted(Context c, boolean value) {
        sp(c).edit().putBoolean(KEY_AUTO_DETECT, value).apply();
    }

    public static boolean isCaptureMedia(Context c) {
        return sp(c).getBoolean(KEY_MEDIA, true);
    }

    public static void setCaptureMedia(Context c, boolean value) {
        sp(c).edit().putBoolean(KEY_MEDIA, value).apply();
    }
}
