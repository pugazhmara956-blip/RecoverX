package com.recoverx.app.ui;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.recoverx.app.R;
import com.recoverx.app.data.CapturedMessage;
import com.recoverx.app.data.DatabaseHelper;
import com.recoverx.app.util.AppUtils;

import java.util.List;

/** Dashboard: totals, storage, notification access status and recent notifications. */
public class HomeFragment extends Fragment implements DatabaseHelper.ChangeListener {

    private View root;
    private MessageAdapter adapter;

    private static class HomeData {
        DatabaseHelper.Stats stats;
        List<CapturedMessage> recent;
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        root = inflater.inflate(R.layout.fragment_home, container, false);
        setLabel(R.id.stat_total, R.string.stat_total);
        setLabel(R.id.stat_text, R.string.stat_text);
        setLabel(R.id.stat_today, R.string.stat_today);
        setLabel(R.id.stat_deleted, R.string.stat_deleted);

        RecyclerView list = root.findViewById(R.id.recent_list);
        list.setLayoutManager(new LinearLayoutManager(requireContext()));
        adapter = new MessageAdapter(m -> UiHelper.showMessageDetail(requireActivity(), m));
        list.setAdapter(adapter);

        root.findViewById(R.id.btn_fix_access).setOnClickListener(v -> AppUtils.openNotificationAccess(requireActivity()));
        root.findViewById(R.id.btn_quick_search).setOnClickListener(v -> startActivity(new Intent(requireContext(), SearchActivity.class)));
        root.findViewById(R.id.btn_quick_media).setOnClickListener(v -> startActivity(new Intent(requireContext(), MediaActivity.class)));
        root.findViewById(R.id.btn_quick_backup).setOnClickListener(v -> startActivity(new Intent(requireContext(), BackupActivity.class)));
        return root;
    }

    @Override
    public void onStart() {
        super.onStart();
        DatabaseHelper.addListener(this);
    }

    @Override
    public void onResume() {
        super.onResume();
        root.findViewById(R.id.access_card).setVisibility(AppUtils.hasNotificationAccess(requireContext()) ? View.GONE : View.VISIBLE);
        load();
    }

    @Override
    public void onStop() {
        DatabaseHelper.removeListener(this);
        super.onStop();
    }

    @Override
    public void onDataChanged() {
        load();
    }

    private void load() {
        final android.content.Context app = requireContext().getApplicationContext();
        AppUtils.background(() -> {
            HomeData d = new HomeData();
            DatabaseHelper db = DatabaseHelper.get(app);
            d.stats = db.stats(AppUtils.startOfToday());
            DatabaseHelper.Filter f = new DatabaseHelper.Filter();
            f.limit = 8;
            d.recent = db.query(f);
            return d;
        }, d -> {
            if (!isAdded()) return;
            setValue(R.id.stat_total, d.stats.total);
            setValue(R.id.stat_text, d.stats.text);
            setValue(R.id.stat_today, d.stats.today);
            setValue(R.id.stat_deleted, d.stats.deleted);
            ((TextView) root.findViewById(R.id.storage_text)).setText(getString(R.string.storage_used, AppUtils.formatBytes(d.stats.storageBytes)));
            adapter.submit(d.recent);
            root.findViewById(R.id.recent_empty).setVisibility(d.recent.isEmpty() ? View.VISIBLE : View.GONE);
        }, null);
    }

    private void setLabel(int cardId, int labelRes) {
        ((TextView) root.findViewById(cardId).findViewById(R.id.stat_label)).setText(labelRes);
    }

    private void setValue(int cardId, long value) {
        ((TextView) root.findViewById(cardId).findViewById(R.id.stat_value)).setText(String.valueOf(value));
    }
}
