package com.recoverx.app;

import android.app.Application;

import androidx.appcompat.app.AppCompatDelegate;

/** RecoverX always uses its black theme, independent of the system setting. */
public class RecoverXApp extends Application {
    @Override
    public void onCreate() {
        super.onCreate();
        AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES);
    }
}
