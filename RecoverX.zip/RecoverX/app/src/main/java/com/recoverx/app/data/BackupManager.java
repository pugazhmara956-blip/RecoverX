package com.recoverx.app.data;

import android.content.Context;
import android.net.Uri;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Locale;

/** Exports and imports saved records as JSON. Media files are not included in backups. */
public final class BackupManager {

    private static final String FORMAT = "recoverx-backup";
    private static final int FORMAT_VERSION = 1;

    public static final class ImportResult {
        public int added;
        public int skipped;
    }

    private BackupManager() {
    }

    public static String toJson(List<CapturedMessage> messages) throws JSONException {
        JSONArray array = new JSONArray();
        for (CapturedMessage m : messages) {
            JSONObject o = new JSONObject();
            o.put("package_name", m.packageName);
            o.put("conversation", m.conversation);
            o.put("sender_name", m.senderName);
            o.put("message_text", m.messageText);
            o.put("timestamp", m.timestamp);
            o.put("message_type", m.messageType);
            o.put("manually_marked_deleted", m.manuallyMarkedDeleted);
            o.put("possibly_deleted", m.possiblyDeleted);
            o.put("dedupe_key", m.dedupeKey);
            o.put("created_at", m.createdAt);
            array.put(o);
        }
        JSONObject root = new JSONObject();
        root.put("format", FORMAT);
        root.put("version", FORMAT_VERSION);
        root.put("exported_at", System.currentTimeMillis());
        root.put("count", messages.size());
        root.put("records", array);
        return root.toString(2);
    }

    public static List<CapturedMessage> fromJson(String json) throws JSONException {
        JSONObject root = new JSONObject(json);
        if (!FORMAT.equals(root.optString("format"))) throw new JSONException("Not a RecoverX backup");
        JSONArray array = root.getJSONArray("records");
        List<CapturedMessage> list = new ArrayList<>();
        for (int i = 0; i < array.length(); i++) {
            JSONObject o = array.getJSONObject(i);
            CapturedMessage m = new CapturedMessage();
            m.packageName = o.getString("package_name");
            m.conversation = o.optString("conversation", "");
            m.senderName = o.optString("sender_name", "");
            m.messageText = o.optString("message_text", "");
            m.timestamp = o.getLong("timestamp");
            m.messageType = o.optString("message_type", MessageType.TEXT);
            m.manuallyMarkedDeleted = o.optBoolean("manually_marked_deleted", false);
            m.possiblyDeleted = o.optBoolean("possibly_deleted", false);
            m.dedupeKey = o.optString("dedupe_key", "");
            if (m.dedupeKey.isEmpty()) {
                m.dedupeKey = Hashing.dedupeKey(m.packageName, m.conversation, m.senderName, m.messageText, m.timestamp);
            }
            m.createdAt = o.optLong("created_at", System.currentTimeMillis());
            list.add(m);
        }
        return list;
    }

    public static int exportTo(Context context, Uri uri) throws IOException, JSONException {
        List<CapturedMessage> all = DatabaseHelper.get(context).all();
        try (OutputStream out = context.getContentResolver().openOutputStream(uri)) {
            if (out == null) throw new IOException("Cannot open the selected file");
            out.write(toJson(all).getBytes(StandardCharsets.UTF_8));
        }
        return all.size();
    }

    public static ImportResult importFrom(Context context, Uri uri) throws IOException, JSONException {
        try (InputStream in = context.getContentResolver().openInputStream(uri)) {
            if (in == null) throw new IOException("Cannot open the selected file");
            return importRecords(context, fromJson(readAll(in)));
        }
    }

    public static ImportResult importRecords(Context context, List<CapturedMessage> records) {
        DatabaseHelper db = DatabaseHelper.get(context);
        ImportResult result = new ImportResult();
        for (CapturedMessage m : records) {
            if (db.insertIfNew(m) != -1) result.added++;
            else result.skipped++;
        }
        return result;
    }

    // ------------------------------------------------------------------ local backups

    public static File localDir(Context context) {
        File base = context.getExternalFilesDir("backups");
        File dir = base != null ? base : new File(context.getFilesDir(), "backups");
        //noinspection ResultOfMethodCallIgnored
        dir.mkdirs();
        return dir;
    }

    public static File createLocalBackup(Context context) throws IOException, JSONException {
        String name = "RecoverX-backup-" + new SimpleDateFormat("yyyy-MM-dd-HHmmss", Locale.ENGLISH).format(new Date()) + ".json";
        File file = new File(localDir(context), name);
        try (FileOutputStream out = new FileOutputStream(file)) {
            out.write(toJson(DatabaseHelper.get(context).all()).getBytes(StandardCharsets.UTF_8));
        }
        return file;
    }

    public static List<File> listLocalBackups(Context context) {
        File[] files = localDir(context).listFiles((dir, name) -> name.endsWith(".json"));
        List<File> list = files == null ? new ArrayList<>() : new ArrayList<>(Arrays.asList(files));
        list.sort((a, b) -> Long.compare(b.lastModified(), a.lastModified()));
        return list;
    }

    public static ImportResult restoreLocal(Context context, File file) throws IOException, JSONException {
        try (InputStream in = new FileInputStream(file)) {
            return importRecords(context, fromJson(readAll(in)));
        }
    }

    private static String readAll(InputStream in) throws IOException {
        StringBuilder sb = new StringBuilder();
        try (BufferedReader reader = new BufferedReader(new InputStreamReader(in, StandardCharsets.UTF_8))) {
            char[] buffer = new char[8192];
            int n;
            while ((n = reader.read(buffer)) != -1) sb.append(buffer, 0, n);
        }
        return sb.toString();
    }
}
