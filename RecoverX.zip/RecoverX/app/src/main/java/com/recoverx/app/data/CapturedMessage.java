package com.recoverx.app.data;

/** One saved notification message, exactly as Android showed it. */
public class CapturedMessage {
    public long id;
    public String packageName;
    /** Chat or group name, when the notification provides one. */
    public String conversation;
    public String senderName;
    public String messageText;
    public long timestamp;
    public String messageType;
    public boolean manuallyMarkedDeleted;
    /** True when WhatsApp later showed "This message was deleted" in the same chat. */
    public boolean possiblyDeleted;
    /** Path of a preview image inside the app's private storage, or null. */
    public String mediaPath;
    public String dedupeKey;
    public long createdAt;

    public boolean isDeletedRecord() {
        return manuallyMarkedDeleted || possiblyDeleted;
    }
}
