package com.recoverx.app.ui;

import android.content.res.ColorStateList;
import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;

import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.recoverx.app.R;
import com.recoverx.app.util.AppUtils;

/** Hosts the four main sections with a bottom navigation bar. */
public class MainActivity extends AppCompatActivity {

    private static final String KEY_TAB = "tab";
    private int currentTab = R.id.nav_home;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        BottomNavigationView nav = findViewById(R.id.bottom_nav);
        int[][] states = {new int[]{android.R.attr.state_checked}, new int[]{}};
        int[] colors = {ContextCompat.getColor(this, R.color.neon), ContextCompat.getColor(this, R.color.text_secondary)};
        ColorStateList tint = new ColorStateList(states, colors);
        nav.setItemIconTintList(tint);
        nav.setItemTextColor(tint);

        nav.setOnItemSelectedListener(item -> {
            showTab(item.getItemId());
            return true;
        });
        if (savedInstanceState != null) {
            currentTab = savedInstanceState.getInt(KEY_TAB, R.id.nav_home);
        } else {
            showTab(R.id.nav_home);
        }
        nav.setSelectedItemId(currentTab);
    }

    @Override
    protected void onResume() {
        super.onResume();
        AppUtils.requestRebind(this);
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        outState.putInt(KEY_TAB, currentTab);
    }

    private void showTab(int id) {
        if (id == currentTab && getSupportFragmentManager().findFragmentById(R.id.fragment_container) != null) return;
        currentTab = id;
        Fragment fragment;
        if (id == R.id.nav_messages) fragment = new MessagesFragment();
        else if (id == R.id.nav_deleted) fragment = new DeletedFragment();
        else if (id == R.id.nav_settings) fragment = new SettingsFragment();
        else fragment = new HomeFragment();
        getSupportFragmentManager().beginTransaction()
                .setCustomAnimations(android.R.anim.fade_in, android.R.anim.fade_out)
                .replace(R.id.fragment_container, fragment)
                .commit();
    }
}
