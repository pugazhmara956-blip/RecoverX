package com.recoverx.app.ui;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.RecyclerView;

import com.recoverx.app.R;
import com.recoverx.app.data.CapturedMessage;
import com.recoverx.app.data.MessageType;
import com.recoverx.app.util.AppUtils;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/** Shows saved messages in a list. */
public class MessageAdapter extends RecyclerView.Adapter<MessageAdapter.Holder> {

    public interface OnMessageClick {
        void onClick(CapturedMessage message);
    }

    private final List<CapturedMessage> items = new ArrayList<>();
    private final OnMessageClick listener;

    public MessageAdapter(OnMessageClick listener) {
        this.listener = listener;
    }

    @SuppressWarnings("NotifyDataSetChanged")
    public void submit(List<CapturedMessage> list) {
        items.clear();
        items.addAll(list);
        notifyDataSetChanged();
    }

    static class Holder extends RecyclerView.ViewHolder {
        final TextView avatar, sender, time, chat, text, type, status;

        Holder(View v) {
            super(v);
            avatar = v.findViewById(R.id.msg_avatar);
            sender = v.findViewById(R.id.msg_sender);
            time = v.findViewById(R.id.msg_time);
            chat = v.findViewById(R.id.msg_chat);
            text = v.findViewById(R.id.msg_text);
            type = v.findViewById(R.id.msg_type);
            status = v.findViewById(R.id.msg_status);
        }
    }

    @NonNull
    @Override
    public Holder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return new Holder(LayoutInflater.from(parent.getContext()).inflate(R.layout.item_message, parent, false));
    }

    @Override
    public void onBindViewHolder(@NonNull Holder h, int position) {
        CapturedMessage m = items.get(position);
        String sender = m.senderName == null || m.senderName.isEmpty()
                ? h.itemView.getContext().getString(R.string.unknown_sender) : m.senderName;
        h.sender.setText(sender);
        h.avatar.setText(new String(Character.toChars(sender.codePointAt(0))).toUpperCase(Locale.ENGLISH));
        h.time.setText(AppUtils.formatShort(m.timestamp));
        boolean showChat = m.conversation != null && !m.conversation.isEmpty() && !m.conversation.equals(m.senderName);
        h.chat.setVisibility(showChat ? View.VISIBLE : View.GONE);
        if (showChat) h.chat.setText(m.conversation);
        h.text.setText(m.messageText);
        h.type.setText(MessageType.label(m.messageType));

        if (m.manuallyMarkedDeleted || m.possiblyDeleted) {
            h.status.setVisibility(View.VISIBLE);
            h.status.setText(m.manuallyMarkedDeleted ? R.string.status_marked_deleted : R.string.status_possibly_deleted);
            int color = ContextCompat.getColor(h.itemView.getContext(), m.manuallyMarkedDeleted ? R.color.danger : R.color.warning);
            h.status.setTextColor(color);
        } else {
            h.status.setVisibility(View.GONE);
        }
        h.itemView.setContentDescription(sender + ". " + m.messageText);
        h.itemView.setOnClickListener(v -> listener.onClick(m));
    }

    @Override
    public int getItemCount() {
        return items.size();
    }
}
