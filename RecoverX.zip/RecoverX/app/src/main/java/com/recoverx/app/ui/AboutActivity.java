package com.recoverx.app.ui;

import android.os.Bundle;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.recoverx.app.R;

/** How RecoverX works, its limitations and privacy. */
public class AboutActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_about);
        UiHelper.setupToolbar(this, R.string.about_title);
        String version;
        try {
            version = getPackageManager().getPackageInfo(getPackageName(), 0).versionName;
        } catch (Exception e) {
            version = "1.0 Ultimate";
        }
        ((TextView) findViewById(R.id.about_version)).setText(getString(R.string.version_label, version));
    }
}
