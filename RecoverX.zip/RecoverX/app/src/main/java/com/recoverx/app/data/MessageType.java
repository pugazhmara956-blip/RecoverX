package com.recoverx.app.data;

import com.recoverx.app.R;

import java.util.Locale;

/** Message types, detected from the label WhatsApp puts in the notification text. */
public final class MessageType {
    public static final String TEXT = "TEXT";
    public static final String IMAGE = "IMAGE";
    public static final String VIDEO = "VIDEO";
    public static final String AUDIO = "AUDIO";
    public static final String DOCUMENT = "DOCUMENT";
    public static final String STICKER = "STICKER";
    public static final String OTHER = "OTHER";
    public static final String HIDDEN = "HIDDEN";

    public static final String[] ALL = {TEXT, IMAGE, VIDEO, AUDIO, DOCUMENT, STICKER, OTHER, HIDDEN};

    private MessageType() {
    }

    /** Detects the type from WhatsApp labels such as "📷 Photo" or "🎤 Voice message (0:12)". */
    public static String detect(String text) {
        if (text == null) return TEXT;
        String t = text.trim();
        String lower = t.toLowerCase(Locale.ENGLISH);
        if (t.startsWith("📷") || lower.equals("photo") || lower.startsWith("photo ")) return IMAGE; // 📷
        if (t.startsWith("🎥") || t.startsWith("📹") || lower.equals("video") || lower.startsWith("video ")) return VIDEO; // 🎥 📹
        if (t.startsWith("🎤") || t.startsWith("🎵") || lower.startsWith("voice message") || lower.equals("audio") || lower.startsWith("audio ")) return AUDIO; // 🎤 🎵
        if (t.startsWith("📄") || lower.startsWith("document") || lower.endsWith(".pdf")) return DOCUMENT; // 📄
        if (lower.equals("sticker") || lower.startsWith("👾") || lower.equals("gif") || lower.startsWith("gif ")) return STICKER; // 👾
        if (t.startsWith("📍") || t.startsWith("👤") || t.startsWith("📊")
                || lower.startsWith("location") || lower.startsWith("contact") || lower.startsWith("poll")) return OTHER; // 📍 👤 📊
        if (lower.equals("new message") || lower.matches("^\\d+ new messages?$")) return HIDDEN;
        return TEXT;
    }

    public static boolean isMedia(String type) {
        return IMAGE.equals(type) || VIDEO.equals(type) || AUDIO.equals(type) || DOCUMENT.equals(type);
    }

    public static int label(String type) {
        if (IMAGE.equals(type)) return R.string.type_image;
        if (VIDEO.equals(type)) return R.string.type_video;
        if (AUDIO.equals(type)) return R.string.type_audio;
        if (DOCUMENT.equals(type)) return R.string.type_document;
        if (STICKER.equals(type)) return R.string.type_sticker;
        if (OTHER.equals(type)) return R.string.type_other;
        if (HIDDEN.equals(type)) return R.string.type_hidden;
        return R.string.type_text;
    }
}
