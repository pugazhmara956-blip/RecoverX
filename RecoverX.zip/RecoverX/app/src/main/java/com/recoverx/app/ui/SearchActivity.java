package com.recoverx.app.ui;

import android.content.Context;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.util.Pair;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.button.MaterialButton;
import com.google.android.material.chip.ChipGroup;
import com.google.android.material.datepicker.MaterialDatePicker;
import com.recoverx.app.R;
import com.recoverx.app.data.CapturedMessage;
import com.recoverx.app.data.DatabaseHelper;
import com.recoverx.app.util.AppUtils;

import java.util.Calendar;
import java.util.List;
import java.util.TimeZone;

/** Search by sender or content, with type and date filters and sort order. */
public class SearchActivity extends AppCompatActivity implements DatabaseHelper.ChangeListener {

    private static final long DAY_MS = 24L * 60 * 60 * 1000;

    private String query = "";
    private String type = null;
    private Long fromMillis = null;
    private Long toMillis = null;
    private boolean newestFirst = true;

    private MessageAdapter adapter;
    private TextView resultsCount, emptyText, dateLabel;
    private MaterialButton sortButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_search);
        UiHelper.setupToolbar(this, R.string.search_title);

        resultsCount = findViewById(R.id.results_count);
        emptyText = findViewById(R.id.empty_text);
        dateLabel = findViewById(R.id.date_label);
        sortButton = findViewById(R.id.btn_sort);

        RecyclerView list = findViewById(R.id.list);
        list.setLayoutManager(new LinearLayoutManager(this));
        adapter = new MessageAdapter(m -> UiHelper.showMessageDetail(this, m));
        list.setAdapter(adapter);

        EditText search = findViewById(R.id.search_box);
        search.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
            }

            @Override
            public void afterTextChanged(Editable s) {
                query = s.toString();
                reload();
            }
        });
        search.requestFocus();

        ChipGroup chips = findViewById(R.id.type_chips);
        UiHelper.bindTypeChips(this, chips, selected -> {
            type = selected;
            reload();
        });

        findViewById(R.id.btn_pick_dates).setOnClickListener(v -> pickDates());
        findViewById(R.id.btn_clear_dates).setOnClickListener(v -> {
            fromMillis = null;
            toMillis = null;
            dateLabel.setText(R.string.any_date);
            reload();
        });
        sortButton.setOnClickListener(v -> {
            newestFirst = !newestFirst;
            sortButton.setText(newestFirst ? R.string.sort_newest : R.string.sort_oldest);
            reload();
        });
    }

    @Override
    protected void onStart() {
        super.onStart();
        DatabaseHelper.addListener(this);
        reload();
    }

    @Override
    protected void onStop() {
        DatabaseHelper.removeListener(this);
        super.onStop();
    }

    @Override
    public void onDataChanged() {
        reload();
    }

    private void pickDates() {
        MaterialDatePicker<Pair<Long, Long>> picker = MaterialDatePicker.Builder.dateRangePicker()
                .setTitleText(R.string.date_filter)
                .build();
        picker.addOnPositiveButtonClickListener(selection -> {
            if (selection == null || selection.first == null || selection.second == null) return;
            // The picker returns UTC midnight; convert to local midnight for the chosen days.
            fromMillis = localMidnight(selection.first);
            toMillis = localMidnight(selection.second) + DAY_MS;
            dateLabel.setText(AppUtils.formatDate(fromMillis) + " - " + AppUtils.formatDate(toMillis - 1));
            reload();
        });
        picker.show(getSupportFragmentManager(), "dates");
    }

    private static long localMidnight(long utcMidnight) {
        Calendar utc = Calendar.getInstance(TimeZone.getTimeZone("UTC"));
        utc.setTimeInMillis(utcMidnight);
        Calendar local = Calendar.getInstance();
        local.clear();
        local.set(utc.get(Calendar.YEAR), utc.get(Calendar.MONTH), utc.get(Calendar.DAY_OF_MONTH), 0, 0, 0);
        return local.getTimeInMillis();
    }

    private void reload() {
        final Context app = getApplicationContext();
        final DatabaseHelper.Filter f = new DatabaseHelper.Filter();
        f.query = query;
        f.type = type;
        f.fromMillis = fromMillis;
        f.toMillis = toMillis;
        f.newestFirst = newestFirst;
        f.limit = 2000;
        AppUtils.background(() -> DatabaseHelper.get(app).query(f), (List<CapturedMessage> list) -> {
            if (isFinishing()) return;
            adapter.submit(list);
            resultsCount.setText(getString(R.string.results_count, list.size()));
            emptyText.setVisibility(list.isEmpty() ? View.VISIBLE : View.GONE);
            emptyText.setText(R.string.no_results);
        }, null);
    }
}
