package com.recoverx.app.service;

import android.app.Notification;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.service.notification.NotificationListenerService;
import android.service.notification.StatusBarNotification;
import android.util.Log;

import androidx.core.app.NotificationCompat;
import androidx.core.app.Person;
import androidx.core.os.BundleCompat;

import com.recoverx.app.data.CapturedMessage;
import com.recoverx.app.data.DatabaseHelper;
import com.recoverx.app.data.Hashing;
import com.recoverx.app.data.MessageType;
import com.recoverx.app.data.Prefs;

import java.io.File;
import java.io.FileOutputStream;
import java.util.List;
import java.util.Locale;
import java.util.regex.Pattern;

/**
 * The notification listener. Android binds it only after the user turns on notification access.
 * It reads notifications from explicitly enabled packages only (WhatsApp and WhatsApp Business),
 * saves the visible text locally and ignores every other app, including banks and OTP senders.
 */
public class NotificationCaptureService extends NotificationListenerService {

    private static final String TAG = "NotificationCapture";

    /** WhatsApp system notifications that are not messages. */
    private static final Pattern SYSTEM_TEXT = Pattern.compile(
            "^(\\d+ new messages?( from \\d+ chats?)?|checking for new messages|whatsapp web is currently active"
                    + "|backup in progress.*|waiting for this message.*|calling.*|ringing.*|incoming (voice|video) call"
                    + "|ongoing (voice|video) call|missed (voice|video) call.*|\\d+ missed (voice|video) calls?)$",
            Pattern.CASE_INSENSITIVE);

    private static final String DELETED_NOTICE = "this message was deleted";

    @Override
    public void onListenerConnected() {
        Log.i(TAG, "Notification access connected");
    }

    @Override
    public void onNotificationPosted(StatusBarNotification sbn) {
        try {
            handle(sbn);
        } catch (Exception e) {
            // Never let one unusual notification stop the listener.
            Log.w(TAG, "Could not process a notification", e);
        }
    }

    private void handle(StatusBarNotification sbn) {
        String pkg = sbn.getPackageName();
        if (!Prefs.isPackageEnabled(this, pkg)) return;

        Notification n = sbn.getNotification();
        if (n == null) return;
        if ((n.flags & Notification.FLAG_GROUP_SUMMARY) != 0) return;
        if ((n.flags & Notification.FLAG_ONGOING_EVENT) != 0) return;
        if (Notification.CATEGORY_CALL.equals(n.category)) return;

        Bundle extras = n.extras;
        String title = charSequenceToString(extras.getCharSequence(Notification.EXTRA_TITLE));

        NotificationCompat.MessagingStyle style = NotificationCompat.MessagingStyle.extractMessagingStyleFromNotification(n);
        if (style != null && !style.getMessages().isEmpty()) {
            String conversation = charSequenceToString(style.getConversationTitle());
            if (conversation == null || conversation.isEmpty()) conversation = title;
            List<NotificationCompat.MessagingStyle.Message> messages = style.getMessages();
            for (int i = 0; i < messages.size(); i++) {
                NotificationCompat.MessagingStyle.Message msg = messages.get(i);
                Person person = msg.getPerson();
                String sender = person != null && person.getName() != null ? person.getName().toString() : conversation;
                long time = msg.getTimestamp() > 0 ? msg.getTimestamp() : sbn.getPostTime();
                boolean isLast = i == messages.size() - 1;
                save(pkg, conversation, sender, charSequenceToString(msg.getText()), time, isLast ? extras : null);
            }
            return;
        }

        // Fallback for notifications without MessagingStyle.
        CharSequence big = extras.getCharSequence(Notification.EXTRA_BIG_TEXT);
        CharSequence text = big != null ? big : extras.getCharSequence(Notification.EXTRA_TEXT);
        save(pkg, title, title, charSequenceToString(text), sbn.getPostTime(), extras);
    }

    private void save(String pkg, String conversation, String sender, String text, long time, Bundle extras) {
        if (text == null) return;
        String clean = text.trim();
        if (clean.isEmpty()) return;
        if (SYSTEM_TEXT.matcher(clean).matches()) return;

        String lower = clean.toLowerCase(Locale.ENGLISH);
        if (lower.equals(DELETED_NOTICE) || lower.equals("you deleted this message")) {
            if (Prefs.isAutoDetectDeleted(this)) {
                DatabaseHelper.get(this).flagLatestAsPossiblyDeleted(pkg, conversation, sender, time);
            }
            return;
        }

        CapturedMessage m = new CapturedMessage();
        m.packageName = pkg;
        m.conversation = conversation;
        m.senderName = sender;
        m.messageText = clean;
        m.timestamp = time;
        m.messageType = MessageType.detect(clean);
        m.createdAt = System.currentTimeMillis();
        m.dedupeKey = Hashing.dedupeKey(pkg, conversation, sender, clean, time);

        // Keep a preview only if the notification itself contains a picture.
        if (extras != null && MessageType.IMAGE.equals(m.messageType) && Prefs.isCaptureMedia(this)) {
            Bitmap picture = BundleCompat.getParcelable(extras, Notification.EXTRA_PICTURE, Bitmap.class);
            if (picture != null) m.mediaPath = savePreview(picture, m.dedupeKey);
        }

        DatabaseHelper.get(this).insertIfNew(m);
    }

    private String savePreview(Bitmap bitmap, String key) {
        try {
            File dir = new File(getFilesDir(), "media");
            //noinspection ResultOfMethodCallIgnored
            dir.mkdirs();
            File file = new File(dir, key + ".jpg");
            try (FileOutputStream out = new FileOutputStream(file)) {
                bitmap.compress(Bitmap.CompressFormat.JPEG, 85, out);
            }
            return file.getAbsolutePath();
        } catch (Exception e) {
            Log.w(TAG, "Could not save the media preview", e);
            return null;
        }
    }

    private static String charSequenceToString(CharSequence cs) {
        return cs == null ? null : cs.toString();
    }
}
