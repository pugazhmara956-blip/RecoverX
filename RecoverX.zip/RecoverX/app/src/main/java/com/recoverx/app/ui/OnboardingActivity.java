package com.recoverx.app.ui;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import com.google.android.material.button.MaterialButton;
import com.recoverx.app.R;
import com.recoverx.app.data.Prefs;

/** Three short pages that explain what RecoverX does and does not do. */
public class OnboardingActivity extends AppCompatActivity {

    private static final int[] TITLES = {R.string.onb_title_1, R.string.onb_title_2, R.string.onb_title_3};
    private static final int[] BODIES = {R.string.onb_body_1, R.string.onb_body_2, R.string.onb_body_3};
    private static final int[] ICONS = {R.drawable.ic_message, R.drawable.ic_shield, R.drawable.ic_storage};
    private static final String KEY_PAGE = "page";

    private int page = 0;
    private View content;
    private ImageView icon;
    private TextView title, body, dots;
    private MaterialButton back, next;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_onboarding);
        if (savedInstanceState != null) page = savedInstanceState.getInt(KEY_PAGE, 0);
        content = findViewById(R.id.onb_content);
        icon = findViewById(R.id.onb_icon);
        title = findViewById(R.id.onb_title);
        body = findViewById(R.id.onb_body);
        dots = findViewById(R.id.onb_dots);
        back = findViewById(R.id.onb_back);
        next = findViewById(R.id.onb_next);
        icon.setColorFilter(ContextCompat.getColor(this, R.color.neon));

        back.setOnClickListener(v -> {
            if (page > 0) show(page - 1, true);
        });
        next.setOnClickListener(v -> {
            if (page < TITLES.length - 1) {
                show(page + 1, true);
            } else {
                Prefs.setOnboarded(this);
                startActivity(new Intent(this, SetupActivity.class));
                finish();
            }
        });
        show(page, false);
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        outState.putInt(KEY_PAGE, page);
    }

    private void show(int newPage, boolean animate) {
        page = newPage;
        Runnable apply = () -> {
            icon.setImageResource(ICONS[page]);
            title.setText(TITLES[page]);
            body.setText(BODIES[page]);
            StringBuilder sb = new StringBuilder();
            for (int i = 0; i < TITLES.length; i++) sb.append(i == page ? "● " : "○ ");
            dots.setText(sb.toString().trim());
            back.setVisibility(page == 0 ? View.INVISIBLE : View.VISIBLE);
            next.setText(page == TITLES.length - 1 ? R.string.get_started : R.string.next);
        };
        if (!animate) {
            apply.run();
            return;
        }
        content.animate().alpha(0f).setDuration(150).withEndAction(() -> {
            apply.run();
            content.animate().alpha(1f).setDuration(200).start();
        }).start();
    }
}
